import requests
from bs4 import BeautifulSoup
import csv
import concurrent.futures

CSV = 'links.csv'
HEADERS = {
    'accept': 'application/signed-exchange;v=b3;q=0.7,*/*;q=0.8',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.0.0 Safari/537.36'
}
URL = []


def get_html(url):
    r = requests.get(url, headers=HEADERS)
    return r.text


def get_html_2(url):
    r = requests.get(url, headers=HEADERS)
    return r

def open_list():
    with open(CSV, 'r') as f:
        reader = csv.reader(f)
        for line in reader:
            URL.append(line[0])


count = 0


def get_items(url):
    html = get_html(url)
    resp = get_html_2(url)
    metas = []
    keyword_1 = 'зеркал'
    keyword_2 = 'впн'
    keyword_3 = 'обод'
    keyword_4 = 'обхід'
    keyword_5 = 'vpn'
    keyword_6 = 'блокир'
    keyword_7 = 'блокув'
    keyword_8 = 'блоков'
    soup = BeautifulSoup(html, 'lxml')
    try:
        h1 = soup.find('h1').text
    except AttributeError:
        h1 = 'ERROR'

    try:
        count_1 = soup.find('body').text.count('зеркал')
    except AttributeError:
        count_1 = 'ERROR'
    try:
        count_2 = soup.find('body').text.count('впн')
    except AttributeError:
        count_2 = 'ERROR'
    try:
        count_3 = soup.find('body').text.count('обод')
    except AttributeError:
        count_3 = 'ERROR'
    try:
        count_4 = soup.find('body').text.count('обхід')
    except AttributeError:
        count_4 = 'ERROR'
    try:
        count_5 = soup.find('body').text.count('vpn')
    except AttributeError:
        count_5 = 'ERROR'
    try:
        count_6 = soup.find('body').text.count('блокир')
    except AttributeError:
        count_6 = 'ERROR'
    try:
        count_7 = soup.find('body').text.count('блокув')
    except AttributeError:
        count_7 = 'ERROR'
    try:
        count_8 = soup.find('body').text.count('блоков')
    except AttributeError:
        count_8 = 'ERROR'
    metas.append({
        'url': url,
        'Response': resp,
        'h1': h1,
        'зеркал': count_1,
        'впн': count_2,
        'обод': count_3,
        'обхід': count_4,
        'vpn': count_5,
        'блокир': count_6,
        'блокув': count_7,
        'блоков': count_8


    })

    print(url)
    return metas


def main():
    open_list()

    metas = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=30) as executor:
        futures = [executor.submit(get_items, url) for url in URL]

        for future in concurrent.futures.as_completed(futures):
            metas.extend(future.result())

    with open('output.csv', 'w') as f:
        writer = csv.DictWriter(f, fieldnames=['url', 'Response', 'h1', 'зеркал', 'впн', 'обод', 'обхід', 'vpn',
                                               'блокир', 'блокув', 'блоков'])
        writer.writeheader()
        for meta in metas:
            writer.writerow(meta)


if __name__ == '__main__':
    main()
